For legal reasons, we cannot include BakeryWebsite.zip in the examples folder. To make the example work:

* Download [this zip file](http://blogs.msdn.com/cfs-file.ashx/__key/communityserver-blogs-components-weblogfiles/00-00-00-63-74-metablogapi/3124.Demo_5F00_WindowServer2012R2_2D00_Preview_5F00_4677B514.zip) from [this blog post](http://blogs.msdn.com/b/powershell/archive/2013/07/29/powershell-sessions-slides-and-demos-from-teched-2013.aspx)
* Extract the PreReq/BakeryWebsite folder to C:\BakeryWebsite